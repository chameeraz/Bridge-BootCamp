package com.InvoiceSystem;
import views.Customer;
import views.Home;
import views.Invoice;
import views.Product;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        char ans;
        do{
            switch (Home.displayHome()){
                case 1 :
                    Product.productView();
                    break;
                case 2 :
                    Customer.customerView();
                    break;
                case 3 :
                   Invoice.invoiceView();
                    break;
                case 4:
                    break;
                default :
                    System.out.println("Invalid Input");
            }

            System.out.println("----- You are in Main Menu -----");
            System.out.print("Do you want a do any other operation?(y/n) ");
            ans = sc.next().charAt(0);
        }while (ans == 'y' || ans == 'Y');

    }
}
