package controllers;

import connection.DataBaseConnection;
import models.Invoice;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;

public class InvoiceController {

    //add invoice
    public static int addInvoice(Invoice inv) throws ClassNotFoundException, SQLException {
        Connection con = DataBaseConnection.getConnection();

        Statement stmt = con.createStatement();
        String query = "INSERT INTO invoices(invoiceDate,customerName,productName,unitsPerProduct,unitPrice,totalPrice,discount) VALUES('"+ inv.getInvoiceDate() +"','"+ inv.getCustomerName() +"','"+ inv.getProductName() +"','"+ inv.getUnitPrice() +"','"+ inv.getUnitsPerProduct() +"','"+ inv.getTotalPrice() +"','"+ inv.getDiscount() +"')";

        return stmt.executeUpdate(query);
    }

    //get invoice
    public static Invoice getInvoice(String iID) throws SQLException, ClassNotFoundException {
        Connection con = DataBaseConnection.getConnection();

        Invoice inv = null;

        Statement stmt = con.createStatement();
        String query = "SELECT * FROM invoices WHERE invoiceNumber="+iID;
        ResultSet rs = stmt.executeQuery(query);

        //invoiceNumber,invoiceDate,customerName,productName,unitsPerProduct,unitPrice,totalPrice,discount
        while (rs.next()){
            Date invoiceDate = rs.getDate("invoiceDate");
            String customerName = rs.getString("customerName");
            String productName = rs.getString("productName");
            int unitsPerProduct = Integer.parseInt(rs.getString("unitsPerProduct"));
            double unitPrice = Double.parseDouble(rs.getString("unitPrice"));
            double totalPrice = Double.parseDouble(rs.getString("totalPrice"));
            double discount = Double.parseDouble(rs.getString("discount"));

            inv = new Invoice(invoiceDate,customerName,productName,unitsPerProduct,unitPrice,totalPrice,discount);
        }
        return inv;
    }

    //get invoices
    public static ArrayList getInvoices() throws SQLException, ClassNotFoundException {
        Connection con = DataBaseConnection.getConnection();

        ArrayList invoicesArray = new ArrayList();

        Statement stmt = con.createStatement();
        String query = "SELECT * FROM invoices";
        ResultSet rs = stmt.executeQuery(query);

        //invoiceNumber,invoiceDate,customerName,productName,unitsPerProduct,unitPrice,totalPrice,discount
        while (rs.next()){
            int invoiceNumber = rs.getInt("invoiceNumber");
            Date invoiceDate = rs.getDate("invoiceDate");
            String customerName = rs.getString("customerName");
            String productName = rs.getString("productName");
            int unitsPerProduct = Integer.parseInt(rs.getString("unitsPerProduct"));
            double unitPrice = Double.parseDouble(rs.getString("unitPrice"));
            double totalPrice = Double.parseDouble(rs.getString("totalPrice"));
            double discount = Double.parseDouble(rs.getString("discount"));

            Invoice inv = new Invoice(invoiceDate,customerName,productName,unitsPerProduct,unitPrice,totalPrice,discount);
            invoicesArray.add(inv);
        }
        return invoicesArray;
    }

    public static LocalDate getToday(){
        return java.time.LocalDate.now();
    }

}
