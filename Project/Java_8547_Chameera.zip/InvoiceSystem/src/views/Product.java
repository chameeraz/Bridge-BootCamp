package views;

import controllers.ProductController;

import java.util.ArrayList;
import java.util.Scanner;

public class Product {
    static char getAnswer(){
        Scanner sc = new Scanner(System.in);
        System.out.println("-----  Product Menu -----");
        System.out.print("Do you want a do any other operation?(y/n) ");
        return sc.next().charAt(0);
    }

    public static void productView(){
        do {
            switch (displayProduct()){
                case 1:
                    addNewProduct();
                    break;
                case 2:
                    updateProduct();
                    break;
                case 3:
                    searchProduct();
                    break;
                case 4:
                    viewAllProducts();
                    break;
                case 5:
                    deleteProduct();
                    break;
                case 6:
                    break;
                default:
                    System.out.println("Invalid Input");
            }

        }while (getAnswer() == 'y');
    }

    static void header(String headerText){
        System.out.println("**** Welcome to Invoice System | - '"+ headerText +"' - | ****");
        System.out.println("Please select correct option \n");
    }

    public static int displayProduct(){
        header("PRODUCT");
        System.out.println("1) Add new product");
        System.out.println("2) Update Product");
        System.out.println("3) Search Product By Id");
        System.out.println("4) View All Products");
        System.out.println("5) Delete Product");
        System.out.println("6) Exit");

        Scanner sc = new Scanner(System.in);
        System.out.print("Enter your choice : ");
        return sc.nextInt();
    }

    public static void addNewProduct(){
        header("ADD NEW PRODUCT");

        //Take data from
        try{
            Scanner sc = new Scanner(System.in);

            System.out.print("Enter product ID : ");
            String pId = sc.next();
            System.out.print("Enter product name : ");
            String pName = sc.next();
            System.out.print("Enter product description : ");
            String pDesc = sc.next();
            System.out.print("Enter product purchase price : ");
            double purchaseP = sc.nextDouble();
            System.out.print("Enter product selling price : ");
            double sellingP = sc.nextDouble();
            System.out.print("Enter quantity : ");
            int quantity = sc.nextInt();

            int addP = ProductController.addProduct(new models.Product( pId ,pName,pDesc,purchaseP,sellingP,quantity));

            if (addP != 0){
                System.out.println("Product Added Successfully!");
            }
            else {
                System.out.println("Something wrong!");
            }
        } catch (Exception ex) {
            System.out.println("Error => "+ex);
            //ex.printStackTrace();
        }finally {
            System.out.println("After All");
        }
    }

    public static void updateProduct(){
        header("UPDATE PRODUCT");

        try{
            Scanner sc = new Scanner(System.in);
            System.out.print("Enter Product ID to Update Data : ");
            String pId = sc.next();

            models.Product pro = ProductController.getProduct(pId);
            //Display Data
            System.out.println("Product name : "+ pro.getProductName());
            System.out.println("Product description : "+pro.getDescription());
            System.out.println("Product purchase price : "+pro.getPurchasePrice());
            System.out.println("Selling price : "+pro.getSellingPrice());
            System.out.println("Quantity : "+pro.getQuantity());

            //Update data
            System.out.println("--- Enter New Data ---");
            System.out.print("Enter product name : ");
            String pName = sc.next();
            System.out.print("Enter product description : ");
            String pDesc = sc.next();
            System.out.print("Enter product purchase price : ");
            double purchaseP = sc.nextDouble();
            System.out.print("Enter product selling price : ");
            double sellingP = sc.nextDouble();
            System.out.print("Enter quantity : ");
            int quantity = sc.nextInt();

            int updateP = ProductController.updateProduct(pId,new models.Product(pId,pName,pDesc,purchaseP,sellingP,quantity));

            if (updateP != 0){
                System.out.println("Product Added Successfully!");
            }
            else {
                System.out.println("Something wrong!");
            }
        }
        catch (Exception ex){
            System.out.println("Error => "+ex);
        }

    }

    public static void searchProduct(){
        header("SEARCH PRODUCT");
        try{
            Scanner sc = new Scanner(System.in);
            System.out.print("Enter Product ID to Search : ");
            String pId = sc.next();

            models.Product pro = ProductController.getProduct(pId);
            //Display Data
            System.out.println("Product ID : "+ pro.getProductId());
            System.out.println("Product name : "+ pro.getProductName());
            System.out.println("Product description : "+pro.getDescription());
            System.out.println("Product purchase price : "+pro.getPurchasePrice());
            System.out.println("Selling price : "+pro.getSellingPrice());
            System.out.println("Quantity : "+pro.getQuantity());

        }
        catch (Exception ex){
            System.out.println("Error => "+ex);
        }

    }

    public static void viewAllProducts(){
        header("ALL PRODUCTS");
        try {
            ArrayList<models.Product> productList = null;
            try {
                try {
                    productList = ProductController.getProducts();
                } catch (Exception ex) {
                    System.out.println("Error => "+ex);
                }
            } catch (Exception ex) {
                System.out.println("Error => "+ex);
            }
            assert productList != null;
            for (models.Product product : productList) {
                Object[] rowData = {product.getProductId(), product.getProductName(), product.getDescription(),product.getPurchasePrice(),product.getSellingPrice(),product.getQuantity()};
                for (Object rowDatum : rowData) {
                    System.out.format("%16s", rowDatum.toString());
                }
                System.out.println();
            }
        } catch (Exception ex) {
            System.out.println("Error => "+ex);
        }
    }

    public static void deleteProduct(){
        header("DELETE PRODUCT");

        try{
            Scanner sc = new Scanner(System.in);
            System.out.print("Enter Product ID to Delete : ");
            String pId = sc.next();

            System.out.print("Are you sure?(y/n)");
            char ans = sc.next().charAt(0);

            if (ans == 'y'){
                ProductController.deleteProduct(pId);
                System.out.println("Product Deleted!");
            }

        }
        catch (Exception ex){
            System.out.println("Error => "+ex);
        }

    }
}
