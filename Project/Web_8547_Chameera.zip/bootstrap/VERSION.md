Bootstrap version - Bootstrap v5.1.3
css file must link - bootstrap.min.css
js file must link - bootstrap.min.js
