function openBar() {
  document.getElementById('sideCategory').style.width = '250px';
  document.getElementById('main').style.marginLeft = '250px';
}

function closeBar() {
  document.getElementById('sideCategory').style.width = '0';
  document.getElementById('main').style.marginLeft = '0';
}
